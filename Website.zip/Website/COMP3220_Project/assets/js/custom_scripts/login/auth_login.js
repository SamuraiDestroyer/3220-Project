function validation() {
    var id = document.login_form.user.value;
    var ps = document.login_form.pass.value;
    if (!id && !ps) {
        alert("User Name and Password fields are empty");
        return false;
    } else {
        if (!id) {
            alert("User Name is empty");
            return false;
        }
        if (!ps) {
            alert("Password field is empty");
            return false;
        }
    }
}