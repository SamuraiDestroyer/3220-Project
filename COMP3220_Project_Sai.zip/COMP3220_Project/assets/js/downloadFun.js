function downloadFile(filePath) {
    const anchor = document.createElement('a');
    anchor.href = filePath;
    anchor.download = ''; // The download attribute. You can specify a filename here if desired
    document.body.appendChild(anchor); // Append to the document
    anchor.click();
}
