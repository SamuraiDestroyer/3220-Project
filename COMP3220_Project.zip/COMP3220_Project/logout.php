<?php

class LogoutPage {
    public function __construct() {
        session_start();
    }

    public function logout() {
        if (!isset($_SESSION['User_ID'])) {
            $user = $_SESSION['User_ID'];
            echo $user;

            session_unset();

            session_destroy();
            header("Location: /COMP3220_PROJECT/user_login.php");
        }
    }
}

$page = new LogoutPage();
$page->logout();

?>
