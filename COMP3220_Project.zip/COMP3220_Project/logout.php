<html>
    <body>
        <?php
            session_start();
            $user = $_SESSION['User_ID'];
            echo $user;

            session_unset();

            session_destroy();
            header("Location: /COMP3220_PROJECT/user_login.php");
        ?>
    </body>
</html>
