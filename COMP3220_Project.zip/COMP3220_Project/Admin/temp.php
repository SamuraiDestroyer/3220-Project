
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <title>Search Open Data | OpenData</title>
    <link rel="icon" type="image/x-icon" href="assets/img/Mi_CLase_LOGOcrop.ico"/>
    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/plugins.css" rel="stylesheet" type="text/css" />
    <!-- END GLOBAL MANDATORY STYLES -->

    <!--  BEGIN CUSTOM STYLE FILE  -->
    <link href="assets/css/users/user-profile.css" rel="stylesheet" type="text/css" />
    <!--  END CUSTOM STYLE FILE  -->
    <style>
      button:hover{
        background-color: grey;
        color: black;
        cursor: pointer;
      }
    </style>
</head>
<body>

    <!--  BEGIN NAVBAR  -->
    <div class="header-container fixed-top">
        <header class="header navbar navbar-expand-sm">

        <ul class="navbar-item theme-brand flex-row  text-center">
                <li class="nav-item theme-logo">
                    <a href="index.html">
                        <img src="assets/img/favicon2.ico" class="navbar-logo" alt="logo">
                    </a>
                </li>
                <li class="nav-item theme-text">
                    <a href="index.html" class="nav-link">OpenData COMP 3220</a>
                </li>
            </ul>

            <ul class="navbar-item flex-row ml-md-0 ml-auto">
                <li class="nav-item align-self-center search-animated">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search toggle-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                    <form class="form-inline search-full form-inline search" role="search">
                        <div class="search-bar">
                            <input type="text" class="form-control search-form-control  ml-lg-auto" placeholder="Search...">
                            <button style="background-color: #1b2e4b; color: #888ea8; border-radius: 4px; border-color: rgba(136, 142, 168, 0.5); border-style: solid; border-width: thin;" style="height: fit-content; width: fit-content;" type="submit">Submit</button>
                        </div>
                    </form>
                </li>
            </ul>

            <ul class="navbar-item flex-row ml-md-auto">
                <li class="nav-item dropdown message-dropdown">
                    <div class="dropdown-menu p-0 position-absolute" aria-labelledby="messageDropdown">

                    </div>
                </li>

                <li class="nav-item dropdown notification-dropdown">
                    <a href="javascript:void(0);" class="nav-link dropdown-toggle" id="notificationDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bell"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg><span class="badge badge-success"></span>
                    </a>
                    <div class="dropdown-menu position-absolute" aria-labelledby="notificationDropdown">
                        <div class="notification-scroll">
                        </div>
                    </div>
                </li>

                <li class="nav-item dropdown user-profile-dropdown">
                    <a href="javascript:void(0);" class="nav-link dropdown-toggle user" id="userProfileDropdown"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                        <img src="assets/img/custom img/person_white_24dp.svg" alt="avatar">
                    </a>
                    <div class="dropdown-menu position-absolute" aria-labelledby="userProfileDropdown">
                        <div class="">
                            <div class="dropdown-item">
                                <a href="user_profile.html"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg> My Profile</a>
                            </div>

                            <div class="dropdown-item">
                                <a href="login.html" onclick=""><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-log-out"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg> Sign Out</a>
                            </div>
                        </div>
                    </div>
                </li>

            </ul>
        </header>
    </div>
    <!--  END NAVBAR  -->

    <!--  BEGIN NAVBAR  -->
    <div class="sub-header-container">
        <header class="header navbar navbar-expand-sm">
            <a href="javascript:void(0);" class="sidebarCollapse" data-placement="bottom"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-menu"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg></a>

            <ul class="navbar-nav flex-row">
                <li>
                    <div class="page-header">

                        <nav class="breadcrumb-one" aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="dashboard.php">Admin</a></li>
                                <li class="breadcrumb-item"><a href="javascript:void(0);">Apps</a></li>
                                <li class="breadcrumb-item"><a href="open_data.php">Open Data Listing</a></li>
                            </ol>
                        </nav>

                    </div>
                </li>
            </ul>
        </header>
    </div>
    <!--  END NAVBAR  -->

    <!--  BEGIN MAIN CONTAINER  -->
    <div class="main-container" id="container">

        <div class="overlay"></div>
        <div class="search-overlay"></div>

        <!--  BEGIN SIDEBAR  -->
        <div class="sidebar-wrapper sidebar-theme">

            <nav id="sidebar">
                <div class="shadow-bottom"></div>

                <ul class="list-unstyled menu-categories" id="accordionExample">
                    <li class="menu">
                        <a class="dropdown-toggle" href="index.html">
                            <div class="">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                                <span>Dashboard</span>
                            </div>
                        </a>
                    </li>

                    <li class="menu">
                        <a href="#app" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                            <div class="">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                                <span>Apps</span>
                            </div>
                            <div>
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                            </div>
                        </a>
                        <ul class="collapse submenu list-unstyled" id="app" data-parent="#accordionExample">
                        <li>
                                <a href="open_data.html" target="_blank">Open Data Listing</a>
                            </li>
                            <li>
                                <a href="data_up_dn.html">Upload/Download</a>
                            </li>
                            <li>
                                <a href="feedback_reporting.html">Feedback/Reporting </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>
        <!--  END SIDEBAR  -->

        <!--  BEGIN CONTENT AREA  -->
        <div id="content" class="main-content">
            <div class="layout-px-spacing">
                <div class="row layout-spacing">
                    <!-- Content -->
                    <div  style="width: 100%; padding: 20px;" >
                        <div class="user-profile layout-spacing">
                            <h3 class="">Open Data Listing</h3>
                            <br>
                            <div class="widget-content widget-content-area">
                                <div>
                                    <div class="" style="width: 100%;">
                                        <ul class="contacts-block list-unstyled">
                                            <li class="contacts-block__item">
                                                Search
                                            </li>

                                            <br>

                                            <input type="text" class="form-control search-form-control  ml-lg-auto" placeholder="Search...">

                                            <br>

                                            <button class="form-control search-form-control  ml-lg-auto"  type="submit">Submit</button>


                                        </li>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <div class="widget-content widget-content-area">
                                <div>
                                    <div class="" style="width: 100%;">
                                        <ul class="contacts-block list-unstyled">
                                            <li class="contacts-block__item">
                                                Open Data List
                                            </li>
                                        </ul>
                                        </center>
                                            <table width=100% border=2 bordercolor='white'>
                                            
                                            <tr>
                                                <th><center>ID</center></th>
                                                <th><center>Title</center></th>
                                                <th><center>URL</center></th>
                                                <th><center>JSON</center></th>
                                                <th><center>CSV</center></th>
                                                <th><center>XML</center></th>

                                            </tr>
                                        </center>

                                        <?php
                                            $db = mysqli_select_db($con,'COMP3220_GrpProject');

                                            $sql = "select * FROM OpenData";
                                            $result = mysqli_query($con, $sql);

                                            echo "<h3><b><u>Active Users:</u></b></h3>";

                                            if (mysqli_num_rows($result) > 0)
                                            {
                                            while($row = mysqli_fetch_array($result))
                                            {
                                                echo "<tr>";
                                                echo "<td><center>" . $row['dataID'] . "</center></td>";
                                                echo "<td><center>" . $row['title'] . "</center></td>";
                                                echo "<td><center>" . $row['url'] . "</center></td>";
                                                echo "<td><center>" . $row['JSON'] . "</center></td>";
                                                echo "<td><center>" . $row['CSV'] . "</center></td>";
                                                echo "<td><center>" . $row['XML'] . "</center></td>";
                                                echo "</tr>";
                                            }
                                            echo "</table>";
                                            }
                                            else
                                            {
                                            echo "0 results";
                                            }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="footer-wrapper"></div>
    <!-- END MAIN CONTAINER -->

    <!--  BEGIN CONTENT AREA  -->

        <div id="content" class="main-content">
          <div class="layout-px-spacing">
            <div class="main">
                <br>
                <center>
                    <h1>
                    Manage Admin
                    </h1>
                </center>


                <center>
                    <table>
                    <tr>
                        <form method="post" action="manage_admin_A.php">
                        <td><label style="font-size: 25px; width: 140px;">Activate:</label></td>
                        <td><input style="border-radius: 15px; border: 2px solid #000000; padding: 20px; width: 400px; height: 0px;" type="text" name="student_id_activate" placeholder="User ID"></td>
                        <td><input style="border-radius: 15px; border: 2px solid #000000; padding: 10px; width: 355px; font-size: 15px; height: 44px; vertical-align: middle;" onclick="window.location.reload(true)" type="submit" value="Activate"></td>
                        </form>
                    </tr>
                    <tr>
                        <form method="post" action="manage_admin_A.php">
                        <td><label style="font-size: 25px; width: 140px;">Deactivate:</label></td>
                        <td><input style="border-radius: 15px; border: 2px solid #000000; padding: 20px; width: 400px; height: 0px;" type="text" name="student_id_deactivate" placeholder="User ID"></td>
                        <td><input style="border-radius: 15px; border: 2px solid #000000; padding: 10px; width: 355px; font-size: 15px; height: 44px; vertical-align: middle;" onclick="window.location.reload(true)" type="submit" value="Deactivate"></td>
                        </form>
                    </tr>
                    </table>
                </center>


                </center>
                    <table width=100% border=2 bordercolor='white'>
                    <br>
                    <tr>
                        <th><center>ID</center></th>
                        <th><center>Name</center></th>
                        <th><center>User Name</center></th>
                        <th><center>Password</center></th>
                        <th><center>Phone</center></th>
                        <th><center>Email</center></th>
                        <th><center>Gender</center></th>
                        <th><center>Date of Birth</center></th>
                        <th><center>Department</center></th>
                        <th><center>Active</center></th>
                        <th><center>Citizenship</center></th>

                    </tr>
                </center>

            <?php
                $db = mysqli_select_db($con,'COMP3220_GrpProject');

                $sql = "SELECT * FROM users WHERE Type='1' AND active='1'";
                $result = mysqli_query($con, $sql);

                echo "<h3><b><u>Active Users:</u></b></h3>";

                if (mysqli_num_rows($result) > 0)
                {
                  while($row = mysqli_fetch_array($result))
                  {
                    echo "<tr>";
                    echo "<td><center>" . $row['id'] . "</center></td>";
                    echo "<td><center>" . $row['name'] . "</center></td>";
                    echo "<td><center>" . $row['username'] . "</center></td>";
                    echo "<td><center>" . $row['password'] . "</center></td>";
                    echo "<td><center>" . $row['phone'] . "</center></td>";
                    echo "<td><center>" . $row['email'] . "</center></td>";
                    echo "<td><center>" . $row['gender'] . "</center></td>";
                    echo "<td><center>" . $row['date_of_birth'] . "</center></td>";
                    echo "<td><center>" . $row['department_id'] . "</center></td>";
                    echo "<td><center>" . $row['active'] . "</center></td>";
                    echo "<td><center>" . $row['citizen'] . "</center></td>";
                    echo "</tr>";
                  }
                  echo "</table>";
                }
                else
                {
                  echo "0 results";
                }
                echo "</fieldset>";
            ?>



            <?php
              $db = mysqli_select_db($con,'COMP3220_GrpProject');

              $sql = "SELECT * FROM users WHERE Type='1' AND active='0'";
              $result = mysqli_query($con, $sql);


              echo "<br><h3><b><u>Deleted Users:</u></b></h3>";

              if (mysqli_num_rows($result) > 0)
              {
                echo "</center>
                  <table width=100% border=2 bordercolor='white'>
                    <br>
                    <tr>
                      <th><center>ID</center></th>
                      <th><center>Name</center></th>
                      <th><center>User Name</center></th>
                      <th><center>Password</center></th>
                      <th><center>Phone</center></th>
                      <th><center>Email</center></th>
                      <th><center>Gender</center></th>
                      <th><center>Date of Birth</center></th>
                      <th><center>Department</center></th>
                      <th><center>Active</center></th>

                    </tr>
                </center>";
                while($row = mysqli_fetch_array($result))
                {
                  echo "<tr>";
                  echo "<td><center>" . $row['id'] . "</center></td>";
                  echo "<td><center>" . $row['name'] . "</center></td>";
                  echo "<td><center>" . $row['username'] . "</center></td>";
                  echo "<td><center>" . $row['password'] . "</center></td>";
                  echo "<td><center>" . $row['phone'] . "</center></td>";
                  echo "<td><center>" . $row['email'] . "</center></td>";
                  echo "<td><center>" . $row['gender'] . "</center></td>";
                  echo "<td><center>" . $row['date_of_birth'] . "</center></td>";
                  echo "<td><center>" . $row['department_id'] . "</center></td>";
                  echo "<td><center>" . $row['active'] . "</center></td>";
                  echo "</tr>";
                }
                echo "</table>";
              }
              else
              {
                echo "0 results";
              }
              echo "</fieldset>";
            ?>

      </div>


          </div>
        </div>

        </div>

        <!--  END CONTENT AREA  -->


    <!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
    <script src="assets/js/libs/jquery-3.1.1.min.js"></script>
    <script src="bootstrap/js/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="assets/js/app.js"></script>


    <script src="assets/js/custom.js"></script>
    <!-- END GLOBAL MANDATORY SCRIPTS -->
</body>

<!-- Mirrored from designreset.com/Mi Clase/ltr/demo3/user_profile.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 25 Jan 2021 13:44:53 GMT -->
</html>
