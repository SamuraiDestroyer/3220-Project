<?php
// Start session
session_start();

// Unset all session variables
$_SESSION = array();

// Destroy the session
session_destroy();

echo "All sessions have been deleted successfully.";
?>
