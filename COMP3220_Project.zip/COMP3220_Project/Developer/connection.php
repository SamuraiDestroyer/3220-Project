<?php

class Database {
    private $host = "localhost";
    private $username = "root";
    private $password = "";
    private $db_name = "COMP3220_GrpProject";
    private $con;

    public function __construct() {
        $this->con = mysqli_connect($this->host, $this->username, $this->password);
        if (!$this->con || !mysqli_select_db($this->con, $this->db_name)) {
            die("Failed to connect with MySQL: " . mysqli_connect_error());
        }
    }

    public function getConnection() {
        return $this->con;
    }
}

$db = new Database();
$con = $db->getConnection();

?>
