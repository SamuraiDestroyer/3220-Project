function generateRandomData(numRows) {
    const names = ['John', 'Jane', 'Bob', 'Alice', 'Michael', 'Emily', 'David', 'Sarah', 'Chris', 'Laura'];
    const domains = ['gmail.com', 'yahoo.com', 'hotmail.com', 'example.com', 'outlook.com'];
    const data = [];

    for (let i = 0; i < numRows; i++) {
        const randomName = names[Math.floor(Math.random() * names.length)];
        const randomAge = Math.floor(Math.random() * 50) + 20; // Generate age between 20 and 70
        const randomEmail = randomName.toLowerCase() + Math.floor(Math.random() * 100) + '@' + domains[Math.floor(Math.random() * domains.length)];
        data.push({ name: randomName, age: randomAge, email: randomEmail });
    }

    return data;
}

const numRows = Math.floor(Math.random() * 11) + 5;
const randomData = generateRandomData(numRows);

function generateTable(data) {
    let table = '<table>';
    table += '<tr><th>Name</th><th>Age</th><th>Email</th></tr>';
    data.forEach(item => {
    table += `<tr><td>${item.name}</td><td>${item.age}</td><td>${item.email}</td></tr>`;
    });
    table += '</table>';
    return table;
}

tableContainer = document.getElementById('tableContainer');
tableContainer.innerHTML = generateTable(randomData);
