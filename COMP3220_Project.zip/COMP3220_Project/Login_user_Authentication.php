<?php

class UserAuthentication {
    private $connection;

    public function __construct($connection) {
        $this->connection = $connection;
    }

    public function authenticateUser($username, $password) {
        if ($username && $password) {
            $username = stripcslashes($username);
            $password = stripcslashes($password);
            $username = mysqli_real_escape_string($this->connection, $username);
            $password = mysqli_real_escape_string($this->connection, $password);

            $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
            $result = mysqli_query($this->connection, $sql);
            $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
            $count = mysqli_num_rows($result);

            if ($count == 1) {
                session_start();
                $_SESSION['User_ID'] = $username;
                $_SESSION['ID'] = $row['id'];

                $ans = $row['type'];

                if ($ans == 1) {
                    header("Location: Admin/dashboard.php");
                } else if ($ans == 2) {
                    header("Location: Developer/dashboard.php");
                } else {
                    header("Location: LocalUser/dashboard.php");
                }
            } else {
                header("Location: /COMP3220_PROJECT/user_login.php");
            }
        }
    }
}

// Usage example:
include('connection.php');

$userAuth = new UserAuthentication($con);
$userAuth->authenticateUser($_POST['user'], $_POST['pass']);

?>
