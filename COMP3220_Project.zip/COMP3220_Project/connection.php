<?php

class DatabaseConnection {
    private $host;
    private $user;
    private $password;
    private $db_name;
    private $connection;

    public function __construct($host, $user, $password, $db_name) {
        $this->host = $host;
        $this->user = $user;
        $this->password = $password;
        $this->db_name = $db_name;
    }

    public function connect() {
        $this->connection = mysqli_connect($this->host, $this->user, $this->password);
        mysqli_select_db($this->connection, $this->db_name);

        if (mysqli_connect_errno()) {
            die("Failed to connect with MySQL: " . mysqli_connect_error());
        }
    }

    public function getConnection() {
        return $this->connection;
    }
}

// Usage example:
$host = "localhost";
$user = "root";
$password = "";
$db_name = "COMP3220_GrpProject";

$dbConnection = new DatabaseConnection($host, $user, $password, $db_name);
$dbConnection->connect();

$con = $dbConnection->getConnection();

?>
