<?php
// require_once "db.php";
// $country_id = $_POST["country_id"];
// $result = mysqli_query($conn,"SELECT * FROM states where country_id = $country_id");
?>
<!-- <option value="">Select State</option> -->
<?php
// while($row = mysqli_fetch_array($result)) {
?>
<!-- <option value="<?php //echo $row["id"];?>"><?php //echo $row["name"];?></option> -->
<?php
// }
?>

<?php
require "connection.php";
$sem = 49;
session_start();
$_SESSION['semester'] = $sem;
// $faculty_id = $_SESSION['faculty_id'];


$result = mysqli_query($con,"SELECT semester FROM class_subject where faculty_id = '$sem'");?>
<option value="">Select Class</option>
<?php
while($row = mysqli_fetch_array($result)) {
    $class_name=$row["semester"];
    $class_query=mysqli_query($con,"SELECT * FROM class_subject WHERE class_name='$class_name'");
    
    while($class_row=mysqli_fetch_array($class_query)){
?>
<h1></h1>
<option value="<?php echo $class_row["id"];?>"><?php echo $class_row["class_name"]."-".$class_row["section"];?></option>

<?php
}
}
?>
