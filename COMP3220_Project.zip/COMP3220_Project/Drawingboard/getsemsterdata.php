<?php
// require_once "db.php";
// $country_id = $_POST["country_id"];
// $result = mysqli_query($conn,"SELECT * FROM states where country_id = $country_id");
?>
<!-- <option value="">Select State</option> -->
<?php
// while($row = mysqli_fetch_array($result)) {
?>
<!-- <option value="<?php //echo $row["id"];?>"><?php //echo $row["name"];?></option> -->
<?php
// }
?>

<?php
require "connection.php";

$class_id = $_POST['class_id'];
session_start();
$sem = $_SESSION['semester'];
// $faculty_id = $_SESSION['user_id'];
$faculty_id = 49;


$result = mysqli_query($con,"SELECT * FROM class_subject WHERE class_id='$class_id' AND semester='$sem' AND faculty_id='$faculty_id'");
?>
<option value="">Select Subject</option>
<?php
while($row = mysqli_fetch_array($result)) {
    $subject_id=$row['subject_id'];
    $subject_query=mysqli_query($con,"SELECT * FROM subjects WHERE id='$subject_id'");
    $subject_row=mysqli_fetch_array($subject_query);
?>
<option value="<?php echo $subject_row["subject_id"];?>"><?php echo $subject_row["subject"];?></option>
<?php
}
?>
