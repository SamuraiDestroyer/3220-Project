<?php
require "connection.php";
$s_id = $_POST['semester_id']; 
session_start();
$_SESSION['semester_id']=$s_id;

//variables
$f_id=49;
$s_id=$_SESSION['semester_id'];

$result= mysqli_query($con,"sELECT * FROM class_subject WHERE faculty_id='$f_id' AND semester='$s_id'");
?>

<option value="">Select Semester</option>

<?php
while($row = mysqli_fetch_array($result))
{
    ?>
    <option value="<?php echo $row["class_id"];?>"><?php echo $row['class_id']; ?> </option>
    <?php
}
?>