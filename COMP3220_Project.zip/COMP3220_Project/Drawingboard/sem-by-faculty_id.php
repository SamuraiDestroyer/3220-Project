<?php
require "connection.php";
$f_id = $_POST['fac_id']; 
session_start();
$_SESSION['faculty_id']=$f_id;
$f_id=$_SESSION['faculty_id'];

$result= mysqli_query($con,"SELECT * FROM class_subject WHERE faculty_id='$f_id'");
?>

<option value="">Select Semester</option>

<?php
while($row = mysqli_fetch_array($result))
{
    ?>
    <option value="<?php echo $row["semester"];?>"><?php echo $row['semester']; ?> </option>
    <?php
}
?>