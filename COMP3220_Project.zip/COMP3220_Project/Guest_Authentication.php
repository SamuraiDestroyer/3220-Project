<?php      
    if( $_POST['user'] and $_POST['pass'])
    {
    include('connection.php');  
    $username = "Guest";
    $password = "Guest";  
      
        //to prevent from mysqli injection  
        $username = stripcslashes($username);  
        $password = stripcslashes($password);  
        $username = mysqli_real_escape_string($con, $username);  
        $password = mysqli_real_escape_string($con, $password);  

        echo $username;
        echo $password;
      
        $sql = "select * from users where username = '$username' and password = '$password'";  
        $result = mysqli_query($con, $sql);  
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        $count = mysqli_num_rows($result);

        echo $username;
        echo $password;
        
        if($count == 1){
                session_start();
                $_SESSION['User_ID'] = $username; 
                
                    $ans = $row['type'];
                    
                    if ($ans == 1) 
                    {
                        
                        header("Location: Admin/dashboard.php");
                    }
                    else if ($ans == 2) 
                    {
                        header("Location: Developer/dashboard.php");
                    }
                    else 
                    {
                        header("Location: LocalUser/dashboard.php");
                    }        
                 }
    }  
?>